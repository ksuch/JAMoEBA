SparkFun Serial Controlled Motor Driver Libraries
==================================================

The SCMD can be operated from a higher level over I2C or SPI using an arduino library.  This library is availabel from [https://github.com/sparkfun/SparkFun_Serial_Controlled_Motor_Driver_Arduino_Library](https://github.com/sparkfun/SparkFun_Serial_Controlled_Motor_Driver_Arduino_Library) or from within the library manager.
